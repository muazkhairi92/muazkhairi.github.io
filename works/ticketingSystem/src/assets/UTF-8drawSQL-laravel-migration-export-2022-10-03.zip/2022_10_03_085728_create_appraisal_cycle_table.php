<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateAppraisalCycleTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('appraisal_cycle', function (Blueprint $table) {
            $table->increments('appraisalCycle_id');
            $table->date('start_date');
            $table->date('end_date');
            $table->date('evaluation_due');
            $table->integer('Evaluation_Format_id')->unique();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('appraisal_cycle');
    }
}
